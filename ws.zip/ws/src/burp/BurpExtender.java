package burp;

import com.google.gson.Gson;
import com.google.gson.JsonObject;

import java.awt.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.io.PrintWriter;
import java.io.UnsupportedEncodingException;
import java.net.UnknownHostException;
import java.util.*;
import java.util.List;
import java.util.concurrent.TimeUnit;
import javax.swing.*;


public class BurpExtender implements IBurpExtender,IHttpListener,IExtensionStateListener,ITab {
    public static PrintWriter stdout;
    private IExtensionHelpers helpers;
    public IBurpExtenderCallbacks cbs;
    public static JPanel jPanelMain;
    public static Boolean ws_status=false;
    public static String flag;

    @Override
    public void registerExtenderCallbacks(IBurpExtenderCallbacks callbacks) throws UnknownHostException {
        callbacks.setExtensionName("ws");
        helpers = callbacks.getHelpers();
        this.cbs = callbacks;
        callbacks.registerHttpListener(this);
        callbacks.registerExtensionStateListener(this);
        stdout = new PrintWriter(callbacks.getStdout(), true);
        stdout.println("log");
        SwingUtilities.invokeLater(new Runnable() {
            @Override
            public void run() {

                jPanelMain = new JPanel();

                jPanelMain.add(new tab().jp);
                jPanelMain.setLayout(new GridLayout(1, 1));
                jPanelMain.setBorder(BorderFactory.createEmptyBorder(20,20,10,20));
                // 设置自定义组件并添加标签
                cbs.customizeUiComponent(jPanelMain);
                cbs.addSuiteTab(BurpExtender.this);
            }
        });
    }

    @Override
    public void extensionUnloaded() {

        stdout.println("关闭成功！");
    }


    public static String getRandomString(int length){

        //1. 定义一个字符串（A-Z，a-z，0-9）即62个数字字母；

        String str="zxcvbnmlkjhgfdsaqwertyuiopQWERTYUIOPASDFGHJKLZXCVBNM1234567890";

        //2. 由Random生成随机数

        Random random=new Random();

        StringBuffer sb=new StringBuffer();

        //3. 长度为几就循环几次

        for(int i=0; i<length; ++i){

            //从62个的数字或字母中选择

            int number=random.nextInt(62);

            //将产生的数字通过length次承载到sb中

            sb.append(str.charAt(number));

        }

        //将承载的字符转换成字符串

        return sb.toString();

    }
    public boolean CheckFlag(IHttpRequestResponse messageInfo){
        //获取整个请求数据内容
        IRequestInfo analyIRequestInfo = helpers.analyzeRequest(messageInfo);
        //请求的url包含路径
        String url=analyIRequestInfo.getUrl().toString();
        //获取请求包
        String request = new String(messageInfo.getRequest());
        byte[] body = request.substring(analyIRequestInfo.getBodyOffset()).getBytes();
        String bodyString= new String(body);
        //获取请求头
        List<String> headers = analyIRequestInfo.getHeaders();


        tab.dtm.getColumnCount();
        stdout.println(tab.dtm.getColumnCount());
        stdout.println(tab.dtm.getRowCount());

        List<Boolean> sign = new ArrayList<>();
        for (int i=0;i<tab.dtm.getRowCount();i++){
            String stu=tab.dtm.getValueAt(i, 0).toString();  //获取状态值
            String maps=tab.dtm.getValueAt(i, 1).toString();  //获取位置
            String flags=tab.dtm.getValueAt(i, 2).toString();  //获取标准

            if(stu.equals("Match")){
                switch (maps){
                    case "Url":
                        if(url.contains(flags)){sign.add(true);}else{sign.add(false);}
                        continue;
                    case "Header":
                        if(headers.toString().contains(flags)){sign.add(true);}else{sign.add(false);}
                        continue;
                    case "Body":
                        if(bodyString.contains(flags)){sign.add(true);}else{sign.add(false);}
                        continue;
                }
            }else if(stu.equals("Not Match")){
                switch (maps){
                    case "Url":
                        if(url.contains(flags)){sign.add(false);}else{sign.add(true);}
                        continue;
                    case "Header":
                        if(headers.toString().contains(flags)){sign.add(false);}else{sign.add(true);}
                        continue;
                    case "Body":
                        if(bodyString.contains(flags)){sign.add(false);}else{sign.add(true);}
                        continue;
                }
            }
        }

        return !sign.contains(false);
    }
    @Override
    public void processHttpMessage(int toolFlag, boolean messageIsRequest, IHttpRequestResponse messageInfo) throws UnsupportedEncodingException {

        List<String> headers;

        if(ws_status&&ChatServerPool.getOnlineUser().size()>0&&CheckFlag(messageInfo)) {
            if (messageIsRequest) {

                IRequestInfo analyIRequestInfo = helpers.analyzeRequest(messageInfo);
                //获取整个请求数据内容
                String request = new String(messageInfo.getRequest());
                stdout.println(request);
                //通过上面的analyIRequestInfo得到请求数据包体（body）的起始偏移
                int bodyOffset = analyIRequestInfo.getBodyOffset();
                //通过起始偏移点得到请求数据包体（body）的内容
                byte[] body = request.substring(bodyOffset).getBytes();
                //通过上面的analyIRequestInfo得到请求数据的请求头列表
                headers = analyIRequestInfo.getHeaders();
                //获取请求包数据
                String bodyString = new String(body);
                //打印数据

                //记录编号发送给前端浏览器，让浏览器修改数据
                String message_id = getRandomString(32);
                Map message = new HashMap<>();
                message.put("uid", message_id);
                Map data = new HashMap<>();
                data.put("state", "request");
                data.put("headers", headers);
                data.put("body", bodyString);
                Gson gson = new Gson();
                String mapJson = gson.toJson(data);
                message.put("data", mapJson);

                String messageJson = gson.toJson(message);
                ChatServerPool.sendMessageToUser(ChatServerPool.getWebSocketByUser("123456"), messageJson);


                String modify_data;
                int num=0;
                while (true) {
                    try {
                        TimeUnit.MICROSECONDS.sleep(100);
                        modify_data = test.savemessage.get(message_id);
                        if (modify_data == null) {
                            if(num>50){
                                return;
                            }
                            num++;
                            continue;
                        } else {
                            test.savemessage.remove(message_id);
                            //stdout.println(modify_data);
                            break;
                        }
                    } catch (InterruptedException e) {
                        System.err.format("IOException: %s%n", e);
                    }
                }
                //前端修改完成后的数据
                HashMap finish_data = new Gson().fromJson(modify_data, HashMap.class);
                List<String> finish_headers = (List<String>) finish_data.get("headers");


                byte[] finish_body = finish_data.get("body").toString().getBytes();

                //stdout.println(finish_headers);
                // stdout.println(headers);

                //重新构造了请求数据
                byte[] newRequest = helpers.buildHttpMessage(finish_headers, finish_body);
                //打印出重新构造的请求数据测试
                //stdout.println(helpers.analyzeRequest(newRequest).getHeaders());
                //发送重新构造的请求数据 里面已经包含有我们添加的X-Forward-For
                messageInfo.setRequest(newRequest);

            } else {

                IResponseInfo analyIResponseInfo = helpers.analyzeResponse(messageInfo.getResponse());

                headers = analyIResponseInfo.getHeaders();

                String response = new String(messageInfo.getResponse());
                int bodyOffset = analyIResponseInfo.getBodyOffset();
                byte[] body = response.substring(bodyOffset).getBytes();

                //获取请求包数据
                String bodyString = new String(body);


                //记录编号发送给前端浏览器，让浏览器修改数据
                String message_id = getRandomString(32);
                Map message = new HashMap<>();
                message.put("uid", message_id);
                Map data = new HashMap<>();
                data.put("state", "response");
                data.put("headers", headers);
                data.put("body", bodyString);
                Gson gson = new Gson();
                String mapJson = gson.toJson(data);
                message.put("data", mapJson);

                String messageJson = gson.toJson(message);
                ChatServerPool.sendMessageToUser(ChatServerPool.getWebSocketByUser("123456"), messageJson);


                String modify_data;

                while (true) {
                    try {
                        TimeUnit.MICROSECONDS.sleep(100);
                        modify_data = test.savemessage.get(message_id);
                        if (modify_data == null) {
                            continue;
                        } else {
                            test.savemessage.remove(message_id);
                            //stdout.println(modify_data);
                            break;
                        }
                    } catch (InterruptedException e) {
                        System.err.format("IOException: %s%n", e);
                    }
                }
                //前端修改完成后的数据
                HashMap finish_data = new Gson().fromJson(modify_data, HashMap.class);
                List<String> finish_headers = (List<String>) finish_data.get("headers");

                byte[] finish_body = finish_data.get("body").toString().getBytes();


                byte[] newResponse = helpers.buildHttpMessage(finish_headers, finish_body);
                messageInfo.setResponse(newResponse);
            }
        }
    }

    @Override
    public String getTabCaption() {
        return "Ws Server";
    }

    @Override
    public Component getUiComponent() {
        return jPanelMain;
    }
}


