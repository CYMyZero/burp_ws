package burp;

import javax.swing.*;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;

public class AddEdit extends JFrame{
    public  JPanel panel1;
    private JTextField 标识textField1;
    private JButton 关闭Button;
    private JButton 确定Button;
    private JComboBox 状态comboBox1;
    private JComboBox 位置comboBox2;


    public AddEdit(String... args){
        this.setVisible(true);  //可见
        this.setTitle("主界面");
        this.setBounds(600,400,400,250);  //设置大小
        this.setDefaultCloseOperation(WindowConstants.DISPOSE_ON_CLOSE);  // 关闭
        this.add(panel1);

        BurpExtender.stdout.println(args.length);
        if(args.length>1){
            状态comboBox1.addItem(args[0]);
            位置comboBox2.addItem(args[1]);
            标识textField1.setText(args[2]);
        }
        状态comboBox1.addItem("Match");
        状态comboBox1.addItem("Not Match");
        位置comboBox2.addItem("Url");
        位置comboBox2.addItem("Header");
        位置comboBox2.addItem("Body");
        确定Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String[] arr = new String[3];
                arr[0]=状态comboBox1.getSelectedItem().toString();
                arr[1]=位置comboBox2.getSelectedItem().toString();
                arr[2]=标识textField1.getText();


                tab.dtm.addRow(arr);
                tab.table1.setModel(tab.dtm);
                AddEdit.this.setVisible(false);
                tab.dtm.removeRow(tab.table1.getSelectedRow());
            }
        });
        关闭Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                AddEdit.this.setVisible(false);
            }
        });
    }
}
