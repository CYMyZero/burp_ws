
package burp;

import java.net.InetSocketAddress;
import java.net.UnknownHostException;
import java.nio.ByteBuffer;
import java.util.Collections;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;


import com.google.gson.Gson;
import org.java_websocket.WebSocket;
import org.java_websocket.WebSocketImpl;
import org.java_websocket.drafts.Draft;
import org.java_websocket.drafts.Draft_6455;
import org.java_websocket.extensions.permessage_deflate.PerMessageDeflateExtension;
import org.java_websocket.handshake.ClientHandshake;
import org.java_websocket.server.WebSocketServer;




public class test extends WebSocketServer {

    private static int openCounter = 0;
    private static int closeCounter = 0;
    private int limit = Integer.MAX_VALUE;

    /*保存连接的收到的消息*/
    public static final Map<String, String> savemessage = new HashMap<String,String>();

    public test(int port, int limit, Draft d) throws UnknownHostException {
        super(new InetSocketAddress(port), Collections.singletonList(d));
        this.limit = limit;
    }

    public test(InetSocketAddress address, Draft d) {
        super(address, Collections.singletonList(d));
    }

    public test(String i, String i1) throws UnknownHostException {
        int port, limit;
        try {
            port = Integer.parseInt(i);
        } catch (Exception e) {
            System.out.println("No port specified. Defaulting to 9003");
            port = 9003;
        }
        try {
            limit = Integer.parseInt(i1);
        } catch (Exception e) {
            System.out.println("No limit specified. Defaulting to MaxInteger");
            limit = Integer.MAX_VALUE;
        }
        PerMessageDeflateExtension perMessageDeflateExtension = new PerMessageDeflateExtension();
        perMessageDeflateExtension.setThreshold(0);
        test test1 = new test(port, limit,
                new Draft_6455(perMessageDeflateExtension));
        test1.setConnectionLostTimeout(0);
        test1.start();

    }

    @Override
    public void onOpen(WebSocket conn, ClientHandshake handshake) {
        this.userjoin("123456",conn);
        conn.send("message");
        openCounter++;
        System.out.println("///////////Opened connection number" + openCounter);
    }

    @Override
    public void onClose(WebSocket conn, int code, String reason, boolean remote) {
        closeCounter++;

        if (closeCounter >= limit) {
            BurpExtender.stdout.println("closed");

            //System.exit(0);
        }
    }

    @Override
    public void onError(WebSocket conn, Exception ex) {
        System.out.println("Error:");
        ex.printStackTrace();
    }

    @Override
    public void onStart() {
        System.out.println("Server started!");
    }

    @Override
    public void onMessage(WebSocket conn, String message) throws InterruptedException {
        Map<String, String> resultMap = new HashMap<>();

        HashMap account = new Gson().fromJson(message,HashMap.class);
        String uid= account.get("uid").toString();
        String data=account.get("data").toString();
        test.savemessage.put(uid,data);

    }


    @Override
    public void onMessage(WebSocket conn, ByteBuffer blob) {
        conn.send(blob);
    }


    /**
     * 用户加入处理
     * @param user
     */
    public void userjoin(String user, WebSocket conn) {


        ChatServerPool.sendMessage("sx");                        //向所有在线用户推送当前用户上线的消息
        ChatServerPool.addUser(user, conn);                            //向连接池添加当前的连接对象
        ChatServerPool.sendMessageToUser(conn, "");    //向当前连接发送当前在线用户的列表
    }

    /**
     * 用户下线处理
     * @param conn
     */
    public void userLeave(WebSocket conn){
        String user = ChatServerPool.getUserByKey(conn);
        boolean b = ChatServerPool.removeUser(conn);				//在连接池中移除连接
        if(b){
            ChatServerPool.sendMessage("");			//把当前用户从所有在线用户列表中删除
            String joinMsg = "{\"from\":\"[系统]\",\"content\":\""+user+"下线了\",\"timestamp\":"+new Date().getTime()+",\"type\":\"message\"}";
            ChatServerPool.sendMessage(joinMsg);					//向在线用户发送当前用户退出的消息
        }
    }
}
