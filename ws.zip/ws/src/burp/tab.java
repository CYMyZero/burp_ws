package burp;

import org.java_websocket.server.WebSocketServer;

import javax.swing.*;
import javax.swing.table.DefaultTableModel;
import javax.swing.table.TableModel;
import javax.swing.table.TableRowSorter;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.net.UnknownHostException;


public class tab {
    public JPanel jp;
    public static JTable table1;
    private JScrollPane JScrollpane1;
    private JButton 添加Button;
    private JButton 编辑Button;
    private JButton 删除Button;
    private JButton 清空Button;
    private JTabbedPane tabbedPane1;
    private JButton 启动Button;
    private JTextField 端口textField1;
    private JTextArea 日志textArea;
    private JScrollPane 日志滑轮scrollpane;
    private JButton 生成js模板Button;
    private JButton 清除Button;
    public static DefaultTableModel dtm;
    public test test; //创建ws

    public tab(){
        端口textField1.setText("12000");
        String[] columnNames = {"状态","位置","标识"}; //标题行;
        String[][] cellData = new String[][]{};
        dtm = new DefaultTableModel(cellData, columnNames) {
            //设置单元格不可编辑
            @Override
            public boolean isCellEditable(int row, int column) {
                return false;
            }
        };
        table1 = new JTable(dtm);
        JScrollpane1.getViewport().add(table1);

        table1.setRowSorter(new TableRowSorter<TableModel>(dtm));

        日志textArea.setEditable(false);
        启动Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                String port = 端口textField1.getText();

                try {
                    test = new test(port, "10");

                } catch (UnknownHostException ex) {
                    ex.printStackTrace();
                }

                BurpExtender.ws_status = true;
                日志textArea.append("启动成功端口：" + port+"\r\n");

            }
        });
        删除Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                int hang= table1.getSelectedRow();
                dtm.removeRow(hang);
                table1.setModel(dtm);

            }
        });
        添加Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                table1.clearSelection();  new AddEdit();
            }
        });
        清空Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                while (dtm.getRowCount() > 0) { dtm.removeRow(0); }
                table1.setModel(dtm);
            }
        });
        编辑Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {

                if(table1.getSelectedRow()!=-1) {
                    String stu = dtm.getValueAt(table1.getSelectedRow(), 0).toString();//状态值
                    String flags = dtm.getValueAt(table1.getSelectedRow(), 1).toString();//标识值
                    String maps = dtm.getValueAt(table1.getSelectedRow(), 2).toString();//位置值

                    new AddEdit(stu, flags, maps);
                }
            }
        });
        生成js模板Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                日志textArea.append(" var   ws = new WebSocket(\"ws://127.0.0.1:12000\");\n" +
                        "        //申请一个WebSocket对象，参数是服务端地址，同http协议使用http://开头一样，WebSocket协议的url使用ws://开头，另外安全的WebSocket协议使用wss://开头\n" +
                        "        ws.onopen = function(){\n" +
                        "            //当WebSocket创建成功时，触发onopen事件\n" +
                        "            console.log(\"websocket连接成功\");\n" +
                        "            //ws.send(\"hello\"); //将消息发送到服务端\n" +
                        "        }\n" +
                        "        ws.onmessage = function(e){\n" +
                        "            //当客户端收到服务端发来的消息时，触发onmessage事件，参数e.data包含server传递过来的数据\n" +
                        "            console.log(\"11111\");\n" +
                        "         try {\n" +
                        "            message=JSON.parse(e.data);\n" +
                        "            console.log(message);\n" +
                        "            reqrep=JSON.parse(message.data);\n" +
                        "            headers=reqrep.headers;\n" +
                        "            bodys=reqrep.body;\n" +
                        "            //console.log(reqrep);\n" +
                        "            if(reqrep.state==\"request\"){\n" +
                        "                //这里修改请求"+
                        "                console.log(headers);\n" +
                        "                console.log(bodys);\n" +
                        "\n" +
                        "            }else if(reqrep.state==\"response\"){\n" +
                        "                //这里修改响应"+
                        "                console.log(headers);\n" +
                        "                console.log(bodys);\n" +
                        "            }else{\n" +
                        "                console.log(\"error!\");\n" +
                        "            }\n" +
                        "            modify_data={\n" +
                        "               \"uid\":message.uid,\n" +
                        "               \"data\":JSON.stringify({\n" +
                        "                  \n" +
                        "                   \"headers\":headers,\n" +
                        "                   \"state\":reqrep.state,\n" +
                        "                   \"body\":bodys\n" +
                        "                   \n" +
                        "               }),\n" +
                        "               \n" +
                        "            }\n" +
                        "            console.log(modify_data);\n" +
                        "            ws.send(JSON.stringify(modify_data))\n" +
                        "         } catch (error) {\n" +
                        "          \n" +
                        "         }\n" +
                        "\n" +
                        "        }\n" +
                        "        ws.onclose = function(e){\n" +
                        "            //当客户端收到服务端发送的关闭连接请求时，触发onclose事件\n" +
                        "            console.log(\"websocket已断开\");\n" +
                        "        }\n" +
                        "        ws.onerror = function(e){\n" +
                        "            //如果出现连接、处理、接收、发送数据失败的时候触发onerror事件\n" +
                        "            console.log(\"websocket发生错误\"+error);\n" +
                        "        }");
            }
        });
        清除Button.addMouseListener(new MouseAdapter() {
            @Override
            public void mouseClicked(MouseEvent e) {
                日志textArea.setText("");
            }
        });
    }

}
